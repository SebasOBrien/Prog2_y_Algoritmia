
/* 
 * File:   main.cpp
 * Author: Sebastián O'Brien
 *
 * Created on 2 de mayo de 2025, 12:43 PM
 */

#include <iostream>

using namespace std;

/*
 * 
 */

bool verificarCasilla(int n, int m, int y, int x, int tablero[][8]){
    return (y>=0 and y<n and x>=0 and x<m and tablero[y][x]!=0 and tablero[y][x]!=3);
}

void laberinto(int n, int m, int y, int x, int tablero[][8], bool &solucion){
    if(!solucion){
        if(tablero[y][x]==2){
            solucion = true;
            return;
        }
        if(verificarCasilla(n, m, y, x, tablero)){
            tablero[y][x]=3; //Casilla visitada
            laberinto(n, m, y, x+1, tablero, solucion);
            laberinto(n, m, y+1, x, tablero, solucion);
            laberinto(n, m, y, x-1, tablero, solucion);
            laberinto(n, m, y-1, x, tablero, solucion);
            if (solucion) tablero[y][x]=7;
        }
    }
    return;
}

void mostrarLaberinto(int n, int m, int tablero[][8]){
    for(int i=0; i<n; i++){
        for(int j=0; j<m; j++){
            cout<<tablero[i][j]<<" ";
        }
        cout<<endl;
    }
}

int main(int argc, char** argv) {

    int tablero[5][8] = {
    {1, 1, 0, 0, 0, 0, 0, 0},
    {0, 1, 1, 0, 1, 0, 2, 1},
    {1, 1, 0, 1, 0, 1, 0, 1},
    {0, 1, 1, 1, 0, 1, 1, 1},
    {0, 0, 0, 1, 1, 1, 0, 1}
};
    
    bool solucion = false;
    
    laberinto(5, 8, 0, 0, tablero, solucion);
    mostrarLaberinto(5, 8, tablero);
    
    return 0;
}


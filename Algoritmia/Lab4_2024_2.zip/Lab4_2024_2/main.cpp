/* 
 * File:   main.cpp
 * Author: alulab14
 *
 * Created on 4 de julio de 2025, 15:08
 */

#include <iostream>

#include "funcionesAB.h"
#include "Elemento.h"
#include "ArbolB.h"

using namespace std;

bool noTieneHijos(struct NodoArbol * nodo) {
    return nodo->derecha == nullptr and nodo->izquierda == nullptr;
}

void recorrerPorPalabrasRecursivo(struct NodoArbol * nodo, char* palabra, int i){
    if(not esNodoVacio(nodo)){
        palabra[i] = nodo->elemento.letra;
        if(noTieneHijos(nodo)) cout << palabra << endl;
        recorrerPorPalabrasRecursivo(nodo->izquierda, palabra, i+1);
        recorrerPorPalabrasRecursivo(nodo->derecha, palabra, i+1);
    }
}

void recorrerPorPalabras(const struct ArbolBinario & arbol){
    char palabra[10]{};
    int i = 0;
    recorrerPorPalabrasRecursivo(arbol.raiz, palabra, i);
}

int main(int argc, char** argv) {
    
    ArbolBinario arbol_1, arbol_2, arbol_3, arbol_4, arbol_5, arbol_6, arbol_7,
            arbol_8, arbol_9, arbol_10, arbol_11, arbol_12, arbol_13, arbol_14, 
            arbol_15, arbol_16, arbol_17, arbol_18, arbol_19;
    
    construir(arbol_1);
    construir(arbol_2);
    construir(arbol_3);
    construir(arbol_4);
    construir(arbol_5);
    construir(arbol_6);
    construir(arbol_7);
    construir(arbol_8);
    construir(arbol_9);
    construir(arbol_10);
    construir(arbol_12);
    construir(arbol_13);
    construir(arbol_14);
    construir(arbol_15);
    construir(arbol_16);
    construir(arbol_17);
    construir(arbol_18);
    construir(arbol_19);
    
    struct Elemento elemento;
    
    //Nivel 6
    elemento.letra = 'O';
    plantarArbolBinario(arbol_1, nullptr, elemento, nullptr);
    elemento.letra = 'S';
    plantarArbolBinario(arbol_2, nullptr, elemento, nullptr);
    elemento.letra = 'S';
    plantarArbolBinario(arbol_3, nullptr, elemento, nullptr);
    
    //Nivel 5
    elemento.letra = 'A';
    plantarArbolBinario(arbol_4, arbol_1, elemento, nullptr);
    elemento.letra = 'A';
    plantarArbolBinario(arbol_5, nullptr, elemento, nullptr);
    elemento.letra = 'O';
    plantarArbolBinario(arbol_6, nullptr, elemento, arbol_2);
    elemento.letra = 'A';
    plantarArbolBinario(arbol_7, nullptr, elemento, nullptr);
    elemento.letra = 'O';
    plantarArbolBinario(arbol_8, nullptr, elemento, arbol_3);
    
    //Nivel 4
    elemento.letra = 'N';
    plantarArbolBinario(arbol_9, nullptr, elemento, nullptr);
    elemento.letra = 'B';
    plantarArbolBinario(arbol_10, arbol_4, elemento, nullptr);
    elemento.letra = 'N';
    plantarArbolBinario(arbol_11, arbol_5, elemento, arbol_6);
    elemento.letra = 'R';
    plantarArbolBinario(arbol_12, arbol_7, elemento, arbol_8);
    
    //Nivel 3
    elemento.letra = 'E';
    plantarArbolBinario(arbol_13, arbol_9, elemento, nullptr);
    elemento.letra = 'L';
    plantarArbolBinario(arbol_14, arbol_10, elemento, nullptr);
    elemento.letra = 'E';
    plantarArbolBinario(arbol_15, arbol_11, elemento, nullptr);
    elemento.letra = 'R';
    plantarArbolBinario(arbol_16, nullptr, elemento, arbol_12);
    
    //Nivel 2
    elemento.letra = 'I';
    plantarArbolBinario(arbol_17, arbol_13, elemento, arbol_14);
    elemento.letra = 'U';
    plantarArbolBinario(arbol_18, arbol_15, elemento, arbol_16);
    
    //Nivel 1
    elemento.letra = 'B';
    plantarArbolBinario(arbol_19, arbol_17, elemento, arbol_18);
    
    recorrerPorPalabras(arbol_19);
    
    

    return 0;
}


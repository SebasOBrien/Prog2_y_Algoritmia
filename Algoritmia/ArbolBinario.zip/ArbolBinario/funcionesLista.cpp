/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

#include "funcionesLista.h"


Nodo *crearNodo(const ElementoLista &elemento,Nodo *siguiente){
    Nodo *nodo=new Nodo;
    nodo->elemento=elemento;
    nodo->siguiente=siguiente;
    return nodo;
}

bool esListaVacia(const Lista &lista){
    return lista.longitud==0;
}

void construir(Lista &lista){
    lista.cabeza=nullptr;
    lista.longitud=0;
}

void insertarAlInicio(Lista &lista,const ElementoLista &elemento){
    Nodo *nuevoNodo=crearNodo(elemento,nullptr);
    
    nuevoNodo->siguiente=lista.cabeza;
    lista.cabeza=nuevoNodo;
    
    lista.longitud++;
}

void insertarAlFinal(Lista &lista,ElementoLista &elemento){
    Nodo *nuevoNodo=crearNodo(elemento,nullptr);
    
    if(esListaVacia(lista))
        lista.cabeza=nuevoNodo;
    else{
        Nodo *temp=lista.cabeza;//Puntero a la cabeza
        
        for(int i=1;i < lista.longitud;i++)//Avanzando hasta el ultimo nodo, i empieza en 1 porque los indices de una lista empiezan desde 1
            temp=temp->siguiente;
            
        temp->siguiente=nuevoNodo;
    }
    
    lista.longitud++;
}

void insertarEnPosicion(Lista &lista,const ElementoLista &elemento,const int &pos){//si se quiere insertar al final se debe colocar la longitud + 1
    if(pos<=0 or pos>lista.longitud+1){
        cout<<"Posicion invalida"<<endl;
    }else{
        Nodo *nuevoNodo=crearNodo(elemento,nullptr);
        Nodo *temp=lista.cabeza, *anterior=nullptr;
        
        for(int i=1;i<pos;i++){
            anterior=temp;
            temp=temp->siguiente;
        }
        nuevoNodo->siguiente=temp;
        
        if(anterior==nullptr){//insertando inicio
            lista.cabeza=nuevoNodo;
        }else{//insertando al final o entre algun nodo
            anterior->siguiente=nuevoNodo;
        }
        
        lista.longitud++;
    }
}

//void imprime(const Lista &lista){
//    if(esListaVacia(lista))
//        cout<<"Es una lista vacia"<<endl;
//    else{
//        Nodo *temp=lista.cabeza;
//        
//        cout<<'[';
//        for(int i=0;i<lista.longitud;i++){
//            imprimeElemento(temp->elemento);
//            if(i+1!=lista.longitud){
//                cout<<", ";
//            }
//            temp=temp->siguiente;
//        }
//        cout<<']'<<endl;
//    }
//}

ElementoLista retornaPrimero(const Lista &lista){
    return lista.cabeza->elemento;
}

ElementoLista retornaUltimo(const Lista &lista){
    Nodo *temp=lista.cabeza;//Puntero a la cabeza
        
    for(int i=1;i < lista.longitud;i++)
        temp=temp->siguiente;
            
     return temp->elemento;
}

ElementoLista retornaElementoPosicion(const Lista &lista,const int &pos){
    if(pos<=0 or pos>lista.longitud){
        cout<<"Posicion invalida"<<endl;
    }else{
        Nodo *temp=lista.cabeza;
        
        for(int i=1;i<pos;i++){
            temp=temp->siguiente;
        }
        
        return temp->elemento;
    }
}

void eliminaPrimero(Lista &lista){
    Nodo *temp=lista.cabeza;
    lista.cabeza=temp->siguiente;
    
    delete temp;
    lista.longitud--;
}

void eliminaUltimo(Lista &lista){
    Nodo *temp=lista.cabeza,*anterior=nullptr;
    
    for(int i=1;i<lista.longitud;i++){
        anterior=temp;
        temp=temp->siguiente;
    }
    
    if(anterior==nullptr){//estamos eliminando la cabeza
        lista.cabeza=temp->siguiente;
        delete temp;
    }else{
        anterior->siguiente=temp->siguiente;
        delete temp;
    }
    
    lista.longitud--;
}

void eliminaElementoPosicion(Lista &lista,const int &pos){
    if(pos<=0 or pos>lista.longitud){
        cout<<"Posicion invalida"<<endl;
    }else{ 
        Nodo *temp=lista.cabeza,*anterior=nullptr;

        for(int i=1;i<pos;i++){
            anterior=temp;
            temp=temp->siguiente;
        }

        if(anterior==nullptr){//estamos eliminando la cabeza
            lista.cabeza=temp->siguiente;
            delete temp;
        }else{
            anterior->siguiente=temp->siguiente;
            delete temp;
        }

        lista.longitud--;
    }
}

void destruir(Lista &lista){
    while(not esListaVacia(lista))
        eliminaPrimero(lista);
}

/************************************************************/
/************************************************************/
/************************************************************/

//void invertirRecursivo(Lista &lista){
//    if(lista.longitud==1)return;//caso base
//    
//    ElementoLista elemento=retornaPrimero(lista);
//    eliminaPrimero(lista);
//    
//    invertirRecursivo(lista);
//    
//    insertarAlFinal(lista,elemento);
//}
//
//void invertirUsandoFuncionesLista(Lista &lista){
//    if(lista.longitud>1){//sino la lista no se puede invertir o ya esta invertida
//        int posPenultimo=lista.longitud-1;
//        
//        while(posPenultimo>=1){
//            ElementoLista penultimoElemento=retornaElementoPosicion(lista,posPenultimo);
//            
//            eliminaElementoPosicion(lista,posPenultimo);
//            insertarAlFinal(lista,penultimoElemento);
//            
//            posPenultimo--;
//        }
//    }
//}
//
//void rotarIzquierda(Lista &lista){
//    if(lista.longitud>1){
//        Nodo *temp=lista.cabeza,*nodoCabeza=lista.cabeza;
//
//        //hago que la cabeza de la lista avance una posicion
//        lista.cabeza=temp->siguiente;
//        
//        for(int i=1;i<lista.longitud;i++)
//            temp=temp->siguiente;
//        
//        temp->siguiente=nodoCabeza;
//    }
//}
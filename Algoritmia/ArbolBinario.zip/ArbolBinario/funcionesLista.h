/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   funcionesLista.h
 * Author: Usuario
 *
 * Created on 12 de julio de 2024, 12:53 PM
 */

#ifndef FUNCIONESLISTA_H
#define FUNCIONESLISTA_H

#include "Lista.h"

#include <iostream>

using namespace std;

Nodo *crearNodo(const ElementoLista &elemento,Nodo *siguiente);
bool esListaVacia(const Lista &lista);
//void imprimeElementoLista(const ElementoListaLista &elemento);

/**************************************************/
void construir(Lista &lista);

void insertarAlInicio(Lista &lista,const ElementoLista &elemento);
void insertarAlFinal(Lista &lista,ElementoLista &elemento);
void insertarEnPosicion(Lista &lista,const ElementoLista &elemento,const int &pos);

//void imprime(const Lista &lista);

ElementoLista retornaPrimero(const Lista &lista);
ElementoLista retornaUltimo(const Lista &lista);
ElementoLista retornaElementoPosicion(const Lista &lista,const int &pos);

void eliminaPrimero(Lista &lista);
void eliminaUltimo(Lista &lista);
void eliminaElementoPosicion(Lista &lista,const int &pos);

void destruir(Lista &lista);

/*********************************************************/

//void invertirRecursivo(Lista &lista);
//void invertirUsandoFuncionesLista(Lista &lista);
////void invertirIteratirvo(Lista &lista);
//
//void rotarIzquierda(Lista &lista);

#endif /* FUNCIONESLISTA_H */


/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   ArbolBinario.h
 * Author: Usuario
 *
 * Created on 15 de julio de 2024, 12:09 PM
 */

#ifndef ARBOLBINARIO_H
#define ARBOLBINARIO_H

#include "NodoArbol.h"


struct ArbolBinario{
    NodoArbol *raiz;
};

#endif /* ARBOLBINARIO_H */


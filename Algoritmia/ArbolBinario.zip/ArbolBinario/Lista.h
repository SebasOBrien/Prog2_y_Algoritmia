/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   Lista.h
 * Author: Usuario
 *
 * Created on 12 de julio de 2024, 12:51 PM
 */

#ifndef LISTA_H
#define LISTA_H

#include "Nodo.h"

struct Lista{
    Nodo *cabeza;
    int longitud;
};

#endif /* LISTA_H */


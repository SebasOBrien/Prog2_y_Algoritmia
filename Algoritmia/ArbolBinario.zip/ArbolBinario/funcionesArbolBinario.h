/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   funcionesArbolBinario.h
 * Author: Usuario
 *
 * Created on 15 de julio de 2024, 12:10 PM
 */

#ifndef FUNCIONESARBOLBINARIO_H
#define FUNCIONESARBOLBINARIO_H

#include "ArbolBinario.h"
#include "funcionesLista.h"

#include <iostream>

using namespace std;

NodoArbol *crearNodoArbol(NodoArbol *&izquierda,const Elemento &elemento,NodoArbol *&derecha);
bool esArbolVacio(const ArbolBinario &arbol);
bool esNodoVacio(NodoArbol *&nodo);
void imprimeElemento(const Elemento &elemento);
int maximo(int a,int b);

void construir(ArbolBinario &arbol);

//sobrecargas de la funcion plantar 
void plantar(ArbolBinario &arbol,ArbolBinario &arbolIzquierda,const Elemento &elemento,
        ArbolBinario &arbolDerecho);
void plantar(ArbolBinario &arbol,NodoArbol *nodoIzquierda,const Elemento &elemento,
        NodoArbol *nodoDerecho);
void plantar(ArbolBinario &arbol,ArbolBinario &arbolIzquierda,const Elemento &elemento,
        NodoArbol *nodoDerecho);
void plantar(ArbolBinario &arbol,NodoArbol *nodoIzquierda,const Elemento &elemento,
        ArbolBinario &arbolDerecho);

//recorridos
void recorrerEnPreOrden(ArbolBinario &arbol);
void recorrerEnPreOrdenRecursivo(NodoArbol *&nodo);

void recorrerEnOrden(ArbolBinario &arbol);
void recorrerEnOrdenRecursivo(NodoArbol *&nodo);

void recorrerEnPostOrden(ArbolBinario &arbol);
void recorrerEnPostOrdenRecursivo(NodoArbol *&nodo);

//para este recorrido necesitamos una cola entonces usare una lista como cola
void recorrerEnAmplitud(const ArbolBinario &arbol);

/**/
int altura(ArbolBinario &arbol);
int alturaRecursivo(NodoArbol *&nodo);

void destruir(ArbolBinario &arbol);

#endif /* FUNCIONESARBOLBINARIO_H */


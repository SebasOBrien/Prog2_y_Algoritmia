/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   Nodo.h
 * Author: Usuario
 *
 * Created on 12 de julio de 2024, 12:51 PM
 */

#ifndef NODO_H
#define NODO_H

#include "NodoArbol.h"


struct ElementoLista{
    NodoArbol *dato;//aqui se cambia los datos que almacena la lista
};

struct Nodo{
    struct ElementoLista elemento;
    Nodo *siguiente;
};

#endif /* NODO_H */


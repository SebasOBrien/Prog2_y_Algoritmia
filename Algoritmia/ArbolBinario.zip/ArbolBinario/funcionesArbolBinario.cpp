/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

#include "funcionesArbolBinario.h"

NodoArbol *crearNodoArbol(NodoArbol *&izquierda,const Elemento &elemento,NodoArbol *&derecha){
    NodoArbol *nodo=new NodoArbol;
    
    nodo->izquierda=izquierda;
    nodo->elemento=elemento;
    nodo->derecha=derecha;
    
    return nodo;
}

bool esArbolVacio(const ArbolBinario &arbol){
    return arbol.raiz==nullptr;
}

bool esNodoVacio(NodoArbol *&nodo){
    return nodo==nullptr;
}

void imprimeElemento(const Elemento &elemento){
    cout<<elemento.dato<<"  ";
}

int maximo(int a,int b){
    return a>=b ? a: b;
}

void construir(ArbolBinario &arbol){
    arbol.raiz=nullptr;
}

void plantar(ArbolBinario &arbol,ArbolBinario &arbolIzquierda,const Elemento &elemento,
        ArbolBinario &arbolDerecho){
    NodoArbol *nuevoNodo=crearNodoArbol(arbolIzquierda.raiz,elemento,arbolDerecho.raiz);
    
    arbol.raiz=nuevoNodo;
}

void plantar(ArbolBinario &arbol,NodoArbol *nodoIzquierda,const Elemento &elemento,
        NodoArbol *nodoDerecho){
    NodoArbol *nuevoNodo=crearNodoArbol(nodoIzquierda,elemento,nodoDerecho);
    
    arbol.raiz=nuevoNodo;
}

void plantar(ArbolBinario &arbol,ArbolBinario &arbolIzquierda,const Elemento &elemento,
        NodoArbol *nodoDerecho){
    NodoArbol *nuevoNodo=crearNodoArbol(arbolIzquierda.raiz,elemento,nodoDerecho);
    
    arbol.raiz=nuevoNodo;
}

void plantar(ArbolBinario &arbol,NodoArbol *nodoIzquierda,const Elemento &elemento,
        ArbolBinario &arbolDerecho){
    NodoArbol *nuevoNodo=crearNodoArbol(nodoIzquierda,elemento,arbolDerecho.raiz);
    
    arbol.raiz=nuevoNodo;
}

void recorrerEnPreOrden(ArbolBinario &arbol){
    recorrerEnPreOrdenRecursivo(arbol.raiz);
}

void recorrerEnPreOrdenRecursivo(NodoArbol *&nodo){
    if(not esNodoVacio(nodo)){
        imprimeElemento(nodo->elemento);
        recorrerEnPreOrdenRecursivo(nodo->izquierda);
        recorrerEnPreOrdenRecursivo(nodo->derecha);
    }
}

void recorrerEnOrden(ArbolBinario &arbol){
    recorrerEnOrdenRecursivo(arbol.raiz);
}

void recorrerEnOrdenRecursivo(NodoArbol *&nodo){
    if(not esNodoVacio(nodo)){
        recorrerEnOrdenRecursivo(nodo->izquierda);
        imprimeElemento(nodo->elemento);
        recorrerEnOrdenRecursivo(nodo->derecha);
    }
}

void recorrerEnPostOrden(ArbolBinario &arbol){
    recorrerEnPostOrdenRecursivo(arbol.raiz);
}

void recorrerEnPostOrdenRecursivo(NodoArbol *&nodo){
    if(not esNodoVacio(nodo)){
        recorrerEnPostOrdenRecursivo(nodo->izquierda);
        recorrerEnPostOrdenRecursivo(nodo->derecha);
        imprimeElemento(nodo->elemento);
    }
}

void recorrerEnAmplitud(const ArbolBinario &arbol){
    Lista cola;//usare la lista como si fuera una cola
    construir(cola);
    
    ElementoLista raiz;
    raiz.dato=arbol.raiz;
    insertarAlFinal(cola,raiz);
    
    while(not esListaVacia(cola)){
        ElementoLista elemento=retornaPrimero(cola);
        eliminaPrimero(cola);
        NodoArbol *aux=elemento.dato;
        
        imprimeElemento(aux->elemento);
        
        if(not esNodoVacio(aux->izquierda)){
            ElementoLista izq;
            izq.dato=aux->izquierda;
            insertarAlFinal(cola,izq);
        }
        if(not esNodoVacio(aux->derecha)){
            ElementoLista der;
            der.dato=aux->derecha;
            insertarAlFinal(cola,der);
        }
    }
}

int altura(ArbolBinario &arbol){
    return alturaRecursivo(arbol.raiz);
}

int alturaRecursivo(NodoArbol *&nodo){
    if(esNodoVacio(nodo))
        return 0;
    else if(esNodoVacio(nodo->izquierda) and esNodoVacio(nodo->derecha))
        return 0;
    else
        return 1 + maximo(alturaRecursivo(nodo->izquierda),alturaRecursivo(nodo->derecha));
}

void destruir(ArbolBinario &arbol){//como es un arbol binario no hay un criterio de busqueda asi que basta con eliminar la raiz
    delete arbol.raiz;
    arbol.raiz=nullptr;
}
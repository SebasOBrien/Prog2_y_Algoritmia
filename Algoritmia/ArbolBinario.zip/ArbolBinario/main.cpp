/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

#include "ArbolBinario.h"
#include "funcionesArbolBinario.h"


/* 
 * File:   main.cpp
 * Author: Usuario
 *
 * Created on 15 de julio de 2024, 12:07 PM
 */

/*
 *      Arbol1
            2
       1        3
    4     6        8
 */

int main(int argc, char** argv) {
    ArbolBinario arbol1,arbol2,arbol3,arbol4,arbol5,arbol6;
    //no es necesario construir el arbol 
    construir(arbol1);
    construir(arbol2);
    construir(arbol3);
    construir(arbol4);
    construir(arbol5);
    construir(arbol6);
    
    plantar(arbol4,nullptr,{4},nullptr);
    plantar(arbol6,nullptr,{6},nullptr);
    plantar(arbol5,nullptr,{8},nullptr);
    
    plantar(arbol2,arbol4,{1},arbol6);
    plantar(arbol3,nullptr,{3},arbol5);
    
    plantar(arbol1,arbol2,{2},arbol3);
    
    cout<<"Recorrido en pre-orden: ";
    recorrerEnPreOrden(arbol1);
    cout<<endl;
    
    cout<<"Recorrido en orden: ";
    recorrerEnOrden(arbol1);
    cout<<endl;
    
    cout<<"Recorrido en post-orden: ";
    recorrerEnPostOrden(arbol1);
    cout<<endl;
    
    cout<<"Recorrido en amplitud: ";
    recorrerEnAmplitud(arbol1);
    cout<<endl;
    
    cout<<"La altura del arbol es: "<<altura(arbol1);
    cout<<endl;
    
    destruir(arbol1);
    
    return 0;
}


/* 
 * File:   main.cpp
 * Author: AXEL
 *
 * Created on 27 de noviembre de 2024, 12:24
 */

#include <iostream>
#include <iomanip>
#include <string>
#include <cstring>
using namespace std;
#define NO_ENCONTRADO -1
#include "Cola.h"
#include "funcionesCola.h"
#include "ArbolBB.h"
#include "funcionesABB.h"
#include "Emociones.h"
#include "funcionesAB.h"
#include "funcionesCola.h"
/*
 * 
 */

int devolverFila(struct NodoArbol *raiz,struct Combinaciones matriz[3][3],
        struct Emociones arrEmociones[],int fila,int columna){
    for(fila;fila<3;fila++){
        for(int j=0;j<9;j++){
            if(strcmp(matriz[fila][columna].nombre,arrEmociones[j].nombre)==0){
                for(int k=0;k<3;k++){
                    if(arrEmociones[j].pesos[k]==raiz->elemento)
                        return fila;
                }
            }
        }
        
    }
    return NO_ENCONTRADO;
    
}
int contarCombinaciones(struct NodoArbol *raiz,struct Emociones arrEmociones[],
        struct Combinaciones matriz[3][3],int contador,int fila){
    
    if(esNodoVacio(raiz))
        return 0;
    int filaAux=devolverFila(raiz,matriz,arrEmociones,fila,contador);
    if(fila<0 or filaAux!=fila)return 0;
    if(contador==2){
        return 1;
    }
    else{
       
        return contarCombinaciones(raiz->izquierda,arrEmociones,matriz,contador+1,fila)+
                contarCombinaciones(raiz->derecha,arrEmociones,matriz,contador+1,fila);
        
        
        
    }
    
    
    
    
}
void recorrerAmplitud(struct NodoArbol *raiz,struct Emociones arrEmociones[],
        struct Combinaciones matriz[3][3]){
    int nivel=1,cantidad=0;
    struct Cola cola;
    construir(cola);
    encolar(cola,raiz);
    
    while(not esColaVacia(cola)){
        int tam=longitud(cola);
        
        for(int i=0;i<tam;i++){
            int contador=0;
            struct NodoArbol *nuevoNodo=desencolar(cola);
            
            int fila=devolverFila(nuevoNodo,matriz,arrEmociones,0,0);
            cantidad+=contarCombinaciones(nuevoNodo,arrEmociones,matriz,contador,fila);
            if(not esNodoVacio(nuevoNodo->izquierda)){
                encolar(cola,nuevoNodo->izquierda);
            }
            if(not esNodoVacio(nuevoNodo->derecha)){
                encolar(cola,nuevoNodo->derecha);
            }
        }
        cout<<"nivel "<<nivel<<"-"<<cantidad<<" combinaciones"<<endl;
        cantidad=0;
        nivel++;
    }
    
    
}
void cantidadCombinaciones(struct ArbolBinarioBusqueda &arbol,struct Emociones arrEmociones[],
        struct Combinaciones matriz[3][3]){
    
    recorrerAmplitud(arbol.arbolBinario.raiz,arrEmociones,matriz);
    
    
}



int main(int argc, char** argv) {
    ArbolBinarioBusqueda pesos;
    construir(pesos);
    insertar(pesos,180);
    insertar(pesos,120);
    insertar(pesos,250);
    insertar(pesos,100);
    insertar(pesos,150);
    insertar(pesos,230);
    insertar(pesos,280);
    insertar(pesos,200);
    insertar(pesos,240);
    insertar(pesos,260);
    insertar(pesos,80);
    insertar(pesos,90);
    insertar(pesos,140);
    insertar(pesos,160);
    
    Emociones arrEmociones[9]={{"alegria",180,200},{"tristeza",140,230,80},
    {"temor",240,100},{"furia",280},{"desagrado",250},{"ansiedad",260,120},
    {"envidia",160,240},{"verguenza",120,80},{"aburrimiento",150,230,90}};
    
    Combinaciones matriz[3][3]{{{"ansiedad"},{"aburrimiento"},{"tristeza"}},
    {{"desagrado"},{"tristeza"},{"temor"}},{{"temor"},{"verguenza"},{"aburrimiento"}}};
    
    
    cantidadCombinaciones(pesos,arrEmociones,matriz);
    
    
    
    
    
    return 0;
}




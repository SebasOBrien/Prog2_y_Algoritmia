/* 
 * File:   Emociones.h
 * Author: AXEL
 *
 * Created on 27 de noviembre de 2024, 20:12
 */

#ifndef EMOCIONES_H
#define EMOCIONES_H
struct Emociones{
    char nombre[25];
    int pesos[3]{};
};
struct Combinaciones{
    char nombre[25];
};

#endif /* EMOCIONES_H */


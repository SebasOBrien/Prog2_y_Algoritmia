/* 
 * File:   Elemento.h
 * Author: ANA RONCAL
 *
 * Created on 8 de junio de 2025, 00:37
 */

#ifndef ELEMENTO_H
#define ELEMENTO_H

struct Elemento{
    int numLote;
    int cantidad;
};

#endif /* ELEMENTO_H */
/* 
 * File:   Cola.h
 * Author: ANA RONCAL
 *
 * Created on 5 de mayo de 2025, 10:43
 */

#ifndef COLA_H
#define COLA_H

#include "Lista.h"
struct Cola {
    struct Lista lista;
};

#endif /* COLA_H */
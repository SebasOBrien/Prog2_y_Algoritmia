/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   funcionesAuxiliares.cpp
 * Author: sebas
 * 
 * Created on 30 de abril de 2025, 07:40 PM
 */

#include <iostream>

#include "funcionesAuxiliares.h"

using namespace std;

void hanoi(int n, char desde, char hacia, char aux) {
    if (n == 0) return;
    hanoi(n - 1, desde, aux, hacia);
    escribirMovimiento(n, desde, hacia);
    hanoi(n - 1, aux, hacia, desde);
}

void escribirMovimiento(int n, char inicio, char fin) {
    cout << "Mover disco " << n << " desde " << inicio << " hasta " << fin << endl;
}

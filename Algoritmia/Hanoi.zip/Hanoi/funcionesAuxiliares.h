/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   funcionesAuxiliares.h
 * Author: sebas
 *
 * Created on 30 de abril de 2025, 07:40 PM
 */

#ifndef FUNCIONESAUXILIARES_H
#define FUNCIONESAUXILIARES_H

void hanoi(int n, char desde, char auxiliar, char hacia);
void escribirMovimiento(int n, char inicio, char fin);

#endif /* FUNCIONESAUXILIARES_H */

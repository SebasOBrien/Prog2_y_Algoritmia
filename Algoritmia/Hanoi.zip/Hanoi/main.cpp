
/* 
 * File:   main.cpp
 * Author: Sebastián O'Brien
 *
 * Created on 30 de abril de 2025, 07:38 PM
 */

#include <iostream>

#include "funcionesAuxiliares.h"

using namespace std;

/*
 * 
 */
int main(int argc, char** argv) {
    
    int n;
    
    cout<<"Ingrese el numero de discos: ";
    cin>>n;
    
    hanoi(n, 'A', 'C', 'B');

    return 0;
}



/* 
 * File:   main.cpp
 * Author: Sebastián O'Brien
 *
 * Created on 11 de mayo de 2025, 01:26 PM
 */

#include <iostream>
#include <cstring>

#include "Pila.h"
#include "Elemento.h"
#include "funcionesPila.h"

using namespace std;

bool esSimbolo(char simbolo){
    return simbolo=='+' or simbolo=='-' or simbolo=='*' or simbolo=='/';
}

int calcularResultado(int operando1, int operando2, char operador){
    if(operador == '+') return operando1+operando2;
    if(operador == '-') return operando1-operando2;
    if(operador == '*') return operando1*operando2;
    else return operando1/operando2;
}

int resolverExpresion(char *expresion){
    struct Pila pila;
    construir(pila);
    struct Elemento elemento;
    int operando1, operando2, numero;
    for(int i=strlen(expresion)-1; i>=0; i--){
        if(esSimbolo(expresion[i])){
            elemento = desapilar(pila);
            operando1 = elemento.numero;
            elemento = desapilar(pila);
            operando2 = elemento.numero;
            elemento.numero = calcularResultado(operando1, operando2, expresion[i]);
            apilar(pila, elemento);
        }else{
            numero = expresion[i] - '0';
            elemento.numero = numero;
            apilar(pila, elemento);
        }
    }
    elemento = desapilar(pila);
    return elemento.numero;
}

int main(int argc, char** argv) {

    char expresion[10] = {'+', '1', '*', '+', '4', '3', '-', '5', '2'}; 
    
    cout << "El resultado es: " << resolverExpresion(expresion);
    
    return 0;
}


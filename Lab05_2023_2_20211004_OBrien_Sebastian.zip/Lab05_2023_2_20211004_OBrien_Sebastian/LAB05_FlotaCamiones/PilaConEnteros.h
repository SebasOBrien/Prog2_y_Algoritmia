/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   PilaConEnteros.h
 * Author: sebas
 *
 * Created on 5 de mayo de 2025, 05:36 PM
 */

#include <iostream>
#include <fstream>

using namespace std;

#ifndef PILACONENTEROS_H
#define PILACONENTEROS_H

void * leeNumero(ifstream &);
double calcularNumero(void *, void *);
int cmpNumero(const void *, const void *);
void imprimeNumero(void *, ofstream &);

#endif /* PILACONENTEROS_H */

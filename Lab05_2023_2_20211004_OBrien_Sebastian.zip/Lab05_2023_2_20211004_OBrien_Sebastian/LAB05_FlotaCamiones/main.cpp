
/* 
 * File:   main.cpp
 * Author: Sebastián O'Brien
 *
 * Created on 5 de mayo de 2025, 02:56 PM
 */

#include <iostream>
#include <stdlib.h>

#include "PilaConEnteros.h"
#include "PilaConRegistros.h"
#include "FlotaGenerica.h"

using namespace std;

int main(int argc, char** argv) {

    int numCamiones;
    double pesoMaximo;
    void *flota;
    
    numCamiones=10; pesoMaximo=10;
    cargaCamiones(flota, numCamiones, pesoMaximo, 
            leeNumero, calcularNumero, "numeros.txt");
    qsort(flota, numCamiones, sizeof(void*), cmpNumero);
    muestraCamiones(flota, numCamiones, imprimeNumero, "reporteNum.txt");
    
    numCamiones=100; pesoMaximo=400;
    cargaCamiones(flota, numCamiones, pesoMaximo, 
            leeRegistro, calculaRegistro, "Pedidos3.csv");
    qsort(flota, numCamiones, sizeof(void*), cmpRegistro);
    muestraCamiones(flota, numCamiones, imprimeRegistro, "reporteRegistro.txt");
    
    return 0;
}


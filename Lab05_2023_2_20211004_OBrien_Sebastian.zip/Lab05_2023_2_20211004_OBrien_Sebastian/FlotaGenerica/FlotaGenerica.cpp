/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   FlotaGenerica.cpp
 * Author: sebas
 * 
 * Created on 5 de mayo de 2025, 03:11 PM
 */

#include <iostream>
#include <fstream>
#include <iomanip>

#include "FlotaGenerica.h"

using namespace std;

void push(void *&pila, void *dato) {
    //    void **actual = (void **)pila;
    //    void **anterior = nullptr;
    //    void **nuevo = new void*[2];
    //    nuevo[0] = dato;
    //    while(actual){
    //        anterior = actual;
    //        actual = (void **)actual[1];
    //    }
    //    nuevo[1] = actual;
    //    if(anterior == nullptr) pila = nuevo;
    //    else anterior[1] = nuevo;
    void **nuevo = new void*[2];
    nuevo[0] = dato;
    nuevo[1] = pila;
    pila = nuevo;
}

bool pilaVacia(void *pila) {
    return pila == nullptr;
}

void cargaCamiones(void *&flota, int numCamiones, double pesoMaximo,
        void *(*lee)(ifstream &), double(*calcula)(void *, void *),
        const char* nombreArch) {
    flota = new void*[numCamiones]();
    void **arrCamiones = (void **) flota;
    void *dato = nullptr;
    ifstream arch(nombreArch, ios::in);
    if (not arch.is_open()) {
        cout << "No se pudo abrir el archivo " << nombreArch;
        exit(1);
    }
    int posCamion = 0;
    while (posCamion != numCamiones) {
        dato = lee(arch);
        if (dato == nullptr) break;
        double peso = calcula(arrCamiones[posCamion], dato);
        if (peso <= pesoMaximo) {
            push(arrCamiones[posCamion], dato);
        } else {
            posCamion++;
            push(arrCamiones[posCamion], dato);
        }
    }
}

void muestraCamiones(void *flota, int numCamiones,
        void (*imprime)(void *, ofstream &), const char* nombreArch) {
    ofstream archReporte(nombreArch, ios::out);
    if (not archReporte.is_open()) {
        cout << "No se pudo abrir el archivo " << nombreArch;
        exit(1);
    }
    void **arrCamiones = (void **) flota;
    for (int i = 0; i < numCamiones; i++) {
        void **camion = (void **) arrCamiones[i];
        archReporte << "Camion" << right << setw(5) << i + 1 << ":" <<
                left << "Peso:" << endl;
        while (camion) {
            imprime(camion[0], archReporte);
            camion = (void **) camion[1];
        }
    }
}



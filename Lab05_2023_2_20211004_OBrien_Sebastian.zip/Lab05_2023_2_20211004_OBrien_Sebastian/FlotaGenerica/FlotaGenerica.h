/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   FlotaGenerica.h
 * Author: sebas
 *
 * Created on 5 de mayo de 2025, 03:11 PM
 */

#include <iostream>
#include <fstream>

using namespace std;

#ifndef FLOTAGENERICA_H
#define FLOTAGENERICA_H

void cargaCamiones(void *&, int , double , void *(*lee)(ifstream &), 
        double(*calcula)(void *), const char*);
void push(void *&, void *);
bool pilaVacia(void *);
void muestraCamiones(void *, int, void (*imprime)(void *, ofstream &), 
        const char*);

#endif /* FLOTAGENERICA_H */

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   PilaConRegistros.h
 * Author: sebas
 *
 * Created on 6 de mayo de 2025, 09:40 AM
 */

#include <iostream>
#include <fstream>

using namespace std;

#ifndef PILACONREGISTROS_H
#define PILACONREGISTROS_H

void *leeRegistro(ifstream &archPedidos);
double calculaRegistro(void *pila);
int cmpRegistro(const void *a, const void *b);
void imprimeRegistro(void *dato, ofstream &arch);
char *leeCadenaExacta(ifstream &arch, int max, char delim);

#endif /* PILACONREGISTROS_H */

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   PilaConRegistros.cpp
 * Author: sebas
 * 
 * Created on 6 de mayo de 2025, 09:40 AM
 */

#include <iostream>
#include <fstream>
#include <cstring>
#include <stdlib.h>
#include <iomanip>

using namespace std;

#include "PilaConRegistros.h"

void *leeRegistro(ifstream &archPedidos){
    char *codigo, c;
    codigo = leeCadenaExacta(archPedidos, 10, ',');
    if (codigo == nullptr) return nullptr;
    int dni;
    int *cantidad = new int;
    double *peso = new double;
    archPedidos>>dni>>c>>*cantidad>>c>>*peso;
    archPedidos.ignore();
    void **tripleta = new void *[3];
    tripleta[0]=codigo;
    tripleta[1]=cantidad;
    tripleta[2]=peso;
    return tripleta;
}

double calculaRegistro(void *pila, void *dato){
    void **ptr = (void **)pila;
    void **registro = (void **)dato;
    double peso = *(double *)registro[2];
    double sumaPeso = 0;
    while(ptr){
        void **tripleta = (void **)ptr[0];
        sumaPeso += *(double *)tripleta[2];
        ptr = (void **)ptr[1];
    }
    return sumaPeso + peso;
}

int cmpRegistro(const void *a, const void *b){
    void **ai = *(void ** const *)a, **bi = *(void ** const *)b; 
    void **tripletaA = (void **)ai[0], **tripletaB = (void **)bi[0];
    double pesoA = *(double *)tripletaA[2], pesoB = *(double *)tripletaB[2];
    return pesoA-pesoB;
}

void imprimeRegistro(void *dato, ofstream &arch){
    void **tripleta = (void **)dato;
    char *codigo = (char *)tripleta[0];
    int *cantidad = (int *)tripleta[1];
    double *peso = (double *)tripleta[2];
    arch<<setw(20)<<" "<<codigo<<right<<setw(10)<<*cantidad<<
            fixed<<setprecision(2)<<setw(10)<<*peso<<endl;
}

char *leeCadenaExacta(ifstream &arch, int max, char delim){
    char *cad, buffer[max];
    arch.getline(buffer, max, delim);
    if(arch.eof()) return nullptr;
    cad = new char[strlen(buffer)+1];
    strcpy(cad, buffer);
    return cad;
}


/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   PilaConEnteros.cpp
 * Author: sebas
 * 
 * Created on 5 de mayo de 2025, 05:36 PM
 */

#include <iostream>
#include <fstream>
#include <stdlib.h>
#include <iomanip>

using namespace std;

#include "PilaConEnteros.h"

void *leeNumero(ifstream &archNumeros){
    double *dato = new double;
    archNumeros >> *dato;
    if (archNumeros.eof()) {
        delete dato;
        return nullptr;
    }
    return dato;
}

double calcularNumero(void *pila, void *dato){
    void **ptr = (void **)pila;
    double numero = *(double *)dato; 
    double sumaNumeros = 0;
    while(ptr){
        sumaNumeros += *(double *)ptr[0];
        ptr = (void **)ptr[1];
    }
    return numero + sumaNumeros;
}

int cmpNumero(const void *a, const void *b){
    double ai = *(double *)a, bi = *(double *)b;
    return ai-bi;
}

void imprimeNumero(void *dato, ofstream &arch){
    double *num = (double *)dato;
    arch<<*num<<endl;
}


/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   BibliotecaGenerica.h
 * Author: sebas
 *
 * Created on 7 de mayo de 2025, 03:43 PM
 */

#include <iostream>
#include <fstream>

using namespace std;

#ifndef BIBLIOTECAGENERICA_H
#define BIBLIOTECAGENERICA_H

void crealista(void *&, void *(*lee)(ifstream &), 
        const char *);
void insertaLista(void *&, void *&, void *);
void * quitalista(void *&);
bool listavacia(void *);
void combinalista(void *&, void *&, void *&, 
        int (*cmp)(const void *, const void *));
void imprimelista(void *, void(*imprime)(ofstream &, void *), 
        const char *);

#endif /* BIBLIOTECAGENERICA_H */

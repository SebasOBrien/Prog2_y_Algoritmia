/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   BibliotecaGenerica.cpp
 * Author: sebas
 * 
 * Created on 7 de mayo de 2025, 03:43 PM
 */

#include <iostream>
#include <fstream>
#include <cstdlib>

#include "BibliotecaGenerica.h"

using namespace std;

void crealista(void *&pedidos, void *(*lee)(ifstream &),
        const char *nombreArch) {
    ifstream archPedidos(nombreArch, ios::in);
    if (not archPedidos.is_open()) {
        cout << "No se pudo abrir el archivo " << nombreArch;
        exit(1);
    }
    void **listaPedidos = (void **) pedidos;
    listaPedidos = new void*[2];
    void *dato = nullptr;
    listaPedidos[0] = nullptr; //Cabeza
    listaPedidos[1] = nullptr; //Cola
    while (true) {
        dato = lee(archPedidos);
        if (dato == nullptr) break;
        insertaLista(listaPedidos[0], listaPedidos[1], dato);
    }
    pedidos = listaPedidos;
}

void insertaLista(void *&cabeza, void *&cola, void *dato) {
    void **nodo = nullptr;
    nodo = new void*[2];
        nodo[0] = dato;
        nodo[1] = nullptr;
    if (listavacia(cabeza)) {
        cabeza = nodo;
    } else {
        ((void **)cola)[1] = nodo;
    }
    cola = nodo;
}

void * quitalista(void *&cabeza) {
    void **primero = (void **) cabeza;
    void *dato = primero[0];
    cabeza = primero[1];
    delete[] primero;
    return dato;
}

bool listavacia(void *cabeza) {
    return cabeza == nullptr;
}

void combinalista(void *&lista1, void *&lista2, void *&listaCombinada,
        int (*cmp)(const void *, const void *)) {
    void **listaNueva = new void*[2];
    listaNueva[0] = nullptr;
    listaNueva[1] = nullptr;
    void **detalleLista1 = (void **) lista1;
    void **detalleLista2 = (void **) lista2;
    void *dato = nullptr;
    //Vamos vaciando hasta que una de las listas se acabe
    while(not listavacia(detalleLista1[0]) or not listavacia(detalleLista2[0])){
        /* Si el primer dato de lista1 es mayor que el primer dato de lista2,
         * insertamos el primer dato de lista2 a nuestra listaNueva.
         * Caso contrario, insertamos el primer dato de lista1 */
        if(cmp(detalleLista1[0], detalleLista2[0])>=0)
            dato = quitalista(detalleLista2[0]);
        else dato = quitalista(detalleLista1[0]);
        insertaLista(listaNueva[0], listaNueva[1], dato);
        /* Si se vacia lista1 significa que todos los datos que quedan en lista2 
         * son mayores dado que lista2 está ordenado, entonces solo insertamos 
         * hasta que se acabe la lista */ 
        if(listavacia(detalleLista1[0])){
            while(not listavacia(detalleLista2[0])){
                dato = quitalista(detalleLista2[0]);
                insertaLista(listaNueva[0], listaNueva[1], dato);
            }
        }
        /* Si se vacia lista2 significa que todos los datos que quedan en lista1 
         * son mayores dado que lista1 está ordenado entonces solo insertamos 
         * hasta que se acabe la lista */  
        if(listavacia(detalleLista2[0])){
            while(not listavacia(detalleLista1[0])){
                dato = quitalista(detalleLista1[0]);
                insertaLista(listaNueva[0], listaNueva[1], dato);
            }
        }
    }
    listaCombinada = listaNueva;
}

void imprimelista(void *lista, void(*imprime)(ofstream &, void *),
        const char *nombreArch) {
    ofstream archReporte(nombreArch, ios::out);
    if (not archReporte.is_open()) {
        cout << "No se pudo abrir el archivo " << nombreArch;
        exit(1);
    }
    void **detalleLista = (void **) lista;
    void **nodo = (void **) detalleLista[0];
    while (nodo != nullptr) {
        imprime(archReporte, nodo[0]);
        nodo = (void **) nodo[1];
    }
}
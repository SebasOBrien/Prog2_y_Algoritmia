/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   FuncionesRegistros.h
 * Author: sebas
 *
 * Created on 7 de mayo de 2025, 06:37 PM
 */

#include <iostream>
#include <fstream>

using namespace std;

#ifndef FUNCIONESREGISTROS_H
#define FUNCIONESREGISTROS_H

void * leeregistro(ifstream &);
void imprimeregistro(ofstream &, void *);
int cmpregistro(const void *, const void *);
char *leeCadenaExacta(ifstream &, int, char);

#endif /* FUNCIONESREGISTROS_H */

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   FuncionesRegistros.cpp
 * Author: sebas
 * 
 * Created on 7 de mayo de 2025, 06:37 PM
 */

#include <iostream>
#include <fstream>
#include <cstring>
#include <iomanip>

#include "FuncionesRegistros.h"

using namespace std;

void * leeregistro(ifstream &archNumeros){
    int *num = new int;
    archNumeros>>*num;
    if(archNumeros.eof()){
        delete num;
        return nullptr;
    }
    int *dni = new int;
    char *cod, c;
    archNumeros>>c>>*dni>>c;
    cod = leeCadenaExacta(archNumeros, 10, '\n');
    void **tripleta = new void*[3];
    tripleta[0] = num;
    tripleta[1] = dni;
    tripleta[2] = cod;
    return tripleta;
}

void imprimeregistro(ofstream &archReporte, void *dato){
    void **tripleta = (void **)dato;
    archReporte<<left<<setw(20)<<*(int *)tripleta[0]<<
            setw(20)<<*(int *)tripleta[1]<<
            (char *)tripleta[2]<<endl;
}

int cmpregistro(const void *a, const void *b){
    void **tripletaA = *(void ** const *)a;
    void **tripletaB = *(void ** const *)b;
    int ai = *(int *)tripletaA[0];
    int bi = *(int *)tripletaB[0];
    return ai-bi;
}

char *leeCadenaExacta(ifstream &arch, int max, char delim){
    char *cad, buffer[max];
    arch.getline(buffer, max, delim);
    if(arch.eof()) return nullptr;
    cad = new char[strlen(buffer)+1];
    strcpy(cad, buffer);
    return cad;
}
/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   FuncionesEnteras.h
 * Author: sebas
 *
 * Created on 7 de mayo de 2025, 04:45 PM
 */

#include <iostream>
#include <fstream>

using namespace std;

#ifndef FUNCIONESENTERAS_H
#define FUNCIONESENTERAS_H

void * leenum(ifstream &);
void imprimenum(ofstream &, void *);
int cmpnum(const void *, const void *);

#endif /* FUNCIONESENTERAS_H */

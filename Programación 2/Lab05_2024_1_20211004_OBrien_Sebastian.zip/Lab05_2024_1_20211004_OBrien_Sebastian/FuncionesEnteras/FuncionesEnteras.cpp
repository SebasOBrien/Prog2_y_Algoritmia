/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   FuncionesEnteras.cpp
 * Author: sebas
 * 
 * Created on 7 de mayo de 2025, 04:45 PM
 */

#include <iostream>
#include <fstream>

#include "FuncionesEnteras.h"

using namespace std;

void * leenum(ifstream &archNumeros){
    int *num = new int;
    archNumeros>>*num;
    if(archNumeros.eof()){
        delete num;
        return nullptr;
    }
    return num;
}

void imprimenum(ofstream &archReporte, void *dato){
    archReporte<<*(int *)dato<<endl;
}

int cmpnum(const void *a, const void *b){
    int ai = **(int **)a, bi = **(int **)b;
    return ai-bi;
}


/* 
 * File:   Cliente.h
 * Author: AXEL
 *
 * Created on 1 de junio de 2025, 15:15
 */

#ifndef CLIENTE_H
#define CLIENTE_H
#include <fstream>
class Cliente {
public:
    Cliente();
    Cliente(const Cliente& orig);
    void inicializa();
    void operator = (const Cliente&);
    void setDni(int);
    int getDni()const;
    void setNombre(const char*);
    void getNombre(char*)const;
    void setDistrito(const char*);
    void getDistrito(char*)const;
    void setDescuento(double);
    double getDescuento()const;
    void setTotalPagado(double);
    double getTotalPagado()const;
    void elimina();
    virtual ~Cliente();
private:
    int dni;
    char* nombre;
    char* distrito;
    double descuento;
    double totalPagado;
};

void operator >>(ifstream &,class Cliente &);
void operator <<(ofstream &,class Cliente &);
#endif /* CLIENTE_H */


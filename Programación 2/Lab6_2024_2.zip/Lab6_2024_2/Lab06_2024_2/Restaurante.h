/* 
 * File:   Restaurante.h
 * Author: AXEL
 *
 * Created on 1 de junio de 2025, 15:32
 */

#ifndef RESTAURANTE_H
#define RESTAURANTE_H
#include "Cliente.h"
#include "Plato.h"

class Restaurante {
public:
    Restaurante();
    virtual ~Restaurante();
    void inicialisa();
    void elimina();
    void SetCapacidadPlatos(int capacidadPlatos);
    int GetCapacidadPlatos() const;
    void SetCantPlatos(int cantPlatos);
    int GetCantPlatos() const;
    void SetCapacidadClientes(int capacidadClientes);
    int GetCapacidadClientes() const;
    void SetCantClientes(int cantClientes);
    int GetCantClientes() const;
    void aumentarEspaciosCli();
    void aumentarEspaciosPla();
    void operator <(const char*name);
    void operator <=(const char*name);
    void operator <<=(const char*name);
    void operator >>(const char*name);
    int buscarCliente(int);
    int buscarPlato(const char*);
    void modificarDatos(int ,const char *,int);
    void sacarDatos(int ,int ,int &,int &,
                            double &,double &,
                            double &,double &,int );
private:
    class Cliente *clientes;
    int cantClientes;
    int capacidadClientes;
    class Plato *platos;
    int cantPlatos;
    int capacidadPlatos;
};



#endif /* RESTAURANTE_H */


/* 
 * File:   Plato.cpp
 * Author: AXEL
 * 
 * Created on 1 de junio de 2025, 15:16
 */
#include <iostream>
#include <fstream>
#include <cstring>
#include <iomanip>
using namespace std;
#include "Plato.h"
#include "funcionesAux.h"

//constructores
Plato::Plato() {
    inicialisa();
}


void Plato::inicialisa(){
    atendidos=0;
    categoria=nullptr;
    codigo=nullptr;
    descuento=0.0;
    noAtendidos=0;
    nombre=nullptr;
    precio=0.0;
    preparados=0;
    totalBruto=0.0;
    totalEsperado=0.0;
    totalNeto=0.0;
    
}

Plato::Plato(const Plato& orig) {
    inicialisa();
    *this=orig;
}

Plato::~Plato() {
    
}

void Plato::operator =(const Plato &orig){
    char aux[100];
    orig.getCategoria(aux);
    setCategoria(aux);
    orig.getCodigo(aux);
    setCodigo(aux);
    orig.getNombre(aux);
    setNombre(aux);
    atendidos=orig.atendidos;
    descuento=orig.descuento;
    noAtendidos=orig.noAtendidos;
    precio=orig.precio;
    preparados=orig.preparados;
    totalBruto=orig.totalBruto;
    totalEsperado=orig.totalEsperado;
    totalNeto=orig.totalNeto;
}

//setters y getters
void Plato::setTotalNeto(double totalNeto) {
    this->totalNeto = totalNeto;
}

double Plato::getTotalNeto() const {
    return totalNeto;
}

void Plato::setTotalBruto(double totalBruto) {
    this->totalBruto = totalBruto;
}

double Plato::getTotalBruto() const {
    return totalBruto;
}

void Plato::setTotalEsperado(double totalEsperado) {
    this->totalEsperado = totalEsperado;
}

double Plato::getTotalEsperado() const {
    return totalEsperado;
}

void Plato::setNoAtendidos(int noAtendidos) {
    this->noAtendidos = noAtendidos;
}

int Plato::getNoAtendidos() const {
    return noAtendidos;
}

void Plato::setAtendidos(int atendidos) {
    this->atendidos = atendidos;
}

int Plato::getAtendidos() const {
    return atendidos;
}

void Plato::setDescuento(double descuento) {
    this->descuento = descuento;
}

double Plato::getDescuento() const {
    return descuento;
}

void Plato::setPreparados(int preparados) {
    this->preparados = preparados;
}

int Plato::getPreparados() const {
    return preparados;
}

void Plato::setCategoria(const char* cat) {    
    if(categoria!=nullptr)delete categoria;
    categoria=new char[strlen(cat)+1];
    strcpy(categoria,cat);
}

void Plato::getCategoria(char* cat) const {
    if(categoria==nullptr)cat[0]=0;
    else strcpy(cat,categoria);
}

void Plato::setPrecio(double precio) {
    this->precio = precio;
}

double Plato::getPrecio() const {
    return precio;
}

void Plato::setNombre(const char* name) {
    if(nombre!=nullptr)delete nombre;
    nombre=new char[strlen(name)+1];
    strcpy(nombre,name);
}

void Plato::getNombre(char* name) const {
    if(nombre==nullptr)name[0]=0;
    else strcpy(name,nombre);
}

void Plato::setCodigo(const char* cod) {
    if(codigo!=nullptr)delete codigo;
    codigo=new char[strlen(cod)+1];
    strcpy(codigo,cod);
}

void Plato::getCodigo(char* cod) const {
    if(codigo==nullptr)cod[0]=0;
    else strcpy(cod,codigo);
}

//AP31796,ANTICUCHO DE CORAZON AL PLATO,31.9,APERITIVO,43,19.94%

void operator >> (ifstream & arch,class Plato &plato){
    char buffer[100];
    double precio,desc=0.0;
    int numPlatos;
    arch.getline(buffer,100,',');
    if(arch.eof())return;
    plato.setCodigo(buffer);
    arch.getline(buffer,100,',');
    plato.setNombre(buffer);
    arch>>precio;
    plato.setPrecio(precio);
    arch.get();
    arch.getline(buffer,100,',');
    arch>>numPlatos;
    plato.setPreparados(numPlatos);
    plato.setCategoria(buffer);
    if(arch.get()==','){
        arch>>desc;
        arch.get();
        arch.get();
    }
    plato.setDescuento(desc);
    plato.setTotalEsperado(numPlatos*precio);
}

void operator << (ofstream &arch,class Plato &plato){
    char aux[100];
    plato.getCodigo(aux);
    arch<<left<<setw(12)<<aux;
    plato.getNombre(aux);
    arch<<setw(60)<<aux<<right<<fixed<<setprecision(2)<<setw(10)<<
            plato.getPrecio()<<setw(5)<<' ';
    plato.getCategoria(aux);
    arch<<left<<setw(15)<<aux<<right<<setw(5)<<plato.getPreparados()<<
            setw(10)<<plato.getDescuento()<<"%"<<setw(8)<<plato.getAtendidos()<<
            setw(10)<<plato.getNoAtendidos()<<setw(10)<<plato.getTotalEsperado()<<
            setw(10)<<plato.getTotalBruto()<<setw(10)<<plato.getTotalNeto()<<endl;
    
}
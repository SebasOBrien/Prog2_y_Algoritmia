/* 
 * File:   Plato.h
 * Author: AXEL
 *
 * Created on 1 de junio de 2025, 15:16
 */

#ifndef PLATO_H
#define PLATO_H

class Plato {
public:
    Plato();
    Plato(const Plato& orig);
    
    void inicialisa();
    virtual ~Plato();
    void operator = (const Plato &);
    
    void setTotalNeto(double totalNeto);
    double getTotalNeto() const;
    void setTotalBruto(double totalBruto);
    double getTotalBruto() const;
    void setTotalEsperado(double totalEsperado);
    double getTotalEsperado() const;
    void setNoAtendidos(int noAtendidos);
    int getNoAtendidos() const;
    void setAtendidos(int atendidos);
    int getAtendidos() const;
    void setDescuento(double descuento);
    double getDescuento() const;
    void setPreparados(int preparados);
    int getPreparados() const;
    void setCategoria(const char* categoria);
    void getCategoria(char*) const;
    void setPrecio(double precio);
    double getPrecio() const;
    void setNombre(const char* nombre);
    void getNombre(char*) const;
    void setCodigo(const char* codigo);
    void getCodigo(char*) const;
private:
    char* codigo;
    char* nombre;
    double precio;
    char* categoria;
    int preparados;
    double descuento;
    int atendidos;
    int noAtendidos;
    double totalEsperado;
    double totalBruto;
    double totalNeto;
    
};

void operator >> (ifstream &,class Plato &);
void operator << (ofstream &,class Plato &);
#endif /* PLATO_H */


 /* 
 * File:   Restaurante.cpp
 * Author: AXEL
 * 
 * Created on 1 de junio de 2025, 15:32
 */

#include <fstream>
#include <cstring>
#include <iomanip>
using namespace std;
#define INCREMENTO 5
#include "Restaurante.h"
#include "Cliente.h"
#include "Plato.h"
#include "funcionesAux.h"
#define TAMLINEA 175
Restaurante::Restaurante() {
    inicialisa();
}


Restaurante::~Restaurante() {
    elimina();
}

void Restaurante::inicialisa(){
    cantClientes=0;
    cantPlatos=0;
    capacidadClientes=0;
    capacidadPlatos=0;
    clientes=nullptr;
    platos=nullptr;
}

//getters y setters 

void Restaurante::SetCapacidadPlatos(int capacidadPlatos) {
    this->capacidadPlatos = capacidadPlatos;
}

int Restaurante::GetCapacidadPlatos() const {
    return capacidadPlatos;
}

void Restaurante::SetCantPlatos(int cantPlatos) {
    this->cantPlatos = cantPlatos;
}

int Restaurante::GetCantPlatos() const {
    return cantPlatos;
}

void Restaurante::SetCapacidadClientes(int capacidadClientes) {
    this->capacidadClientes = capacidadClientes;
}

int Restaurante::GetCapacidadClientes() const {
    return capacidadClientes;
}

void Restaurante::SetCantClientes(int cantClientes) {
    this->cantClientes = cantClientes;
}

int Restaurante::GetCantClientes() const {
    return cantClientes;
}

void Restaurante::aumentarEspaciosCli(){
    class Cliente *aux;
    capacidadClientes+=INCREMENTO;
    if(clientes==nullptr){
        clientes= new class Cliente [capacidadClientes]{};
    }else{
        aux=new class Cliente[capacidadClientes]{};
        for(int i=0;i<cantClientes;i++){
            aux[i] = clientes[i];
        }
        delete [] clientes;
        clientes = aux;
    }
}

void Restaurante::operator <(const char *name){
    ifstream arch=abrirArchLectura(name);
    class Cliente cliente;
    while(true){
        arch >> cliente;
        if(arch.eof())break;
        if(cantClientes == capacidadClientes)aumentarEspaciosCli();
        clientes[cantClientes] = cliente;
        cantClientes++;
    }
    
}
void Restaurante::aumentarEspaciosPla(){
    class Plato *aux;
    capacidadPlatos+=INCREMENTO;
    if(platos==nullptr){
        platos= new class Plato [capacidadPlatos]{};
    }else{
        aux=new class Plato[capacidadPlatos]{};
        for(int i=0;i<cantPlatos;i++){
            aux[i] = platos[i];
        }
        delete [] platos;
        platos = aux;
    }
}

void Restaurante::operator <=(const char *name){
    ifstream arch=abrirArchLectura(name);
    class Plato plato;
    while(true){
        arch>>plato;
        if(arch.eof())return;
        if(cantPlatos==capacidadPlatos)aumentarEspaciosPla();
        platos[cantPlatos] = plato;
        cantPlatos++;
    }
}

void Restaurante::operator <<=(const char *name){
    ifstream arch=abrirArchLectura(name);
    char aux[100],c;
    int codPedido,cantSolicitada,dni,cantAtendidos;
    while(true){
        arch>>codPedido>>c>>dni;
        if(arch.eof())break;
        while(arch.get()==','){
            arch.getline(aux,100,',');
            arch>>cantSolicitada;
            modificarDatos(dni,aux,cantSolicitada);
        }
    }
}

void Restaurante::elimina(){
    if(clientes!=nullptr)delete[]clientes;
    if(platos!=nullptr)delete[]platos;
}

int Restaurante::buscarCliente(int dni){
    for(int i=0;clientes[i].getDni()!=0;i++){
        if(clientes[i].getDni()==dni)return i;
    }
    return -1;
}

int Restaurante::buscarPlato(const char *cod){
    char aux[100];
    for(int i=0;platos[i].getPrecio()!=0;i++){
        platos[i].getCodigo(aux);
        if(strcmp(aux,cod)==0)return i;
    }
    return -1;
}

void Restaurante::sacarDatos(int posCli,int posPla,int &cantAtendidos,int &cantNoAtendidos,
        double &precio,double &pagado,
        double &bruto,double &neto,int cantSolicitada){
    cantAtendidos=platos[posPla].getAtendidos();
    cantNoAtendidos =platos[posPla].getNoAtendidos();
    int cantPreparados = platos[posPla].getPreparados();
    if(cantPreparados != cantAtendidos){
        if((cantPreparados - cantAtendidos) <cantSolicitada){
            cantNoAtendidos += cantSolicitada - (cantPreparados - cantAtendidos);
            cantSolicitada = cantPreparados - cantAtendidos;
        }
        precio = platos[posPla].getPrecio();
        bruto = precio * cantSolicitada + platos[posPla].getTotalBruto();
        cantAtendidos +=cantSolicitada;
        precio = precio * cantSolicitada * (1 + (platos[posPla].getDescuento()/100));
        if(posCli >= 0){
            precio = precio * (1 + (clientes[posCli].getDescuento() / 100));
        }
        neto = platos[posPla].getTotalNeto();
        neto += precio;
        pagado = precio + clientes[posCli].getTotalPagado();
    }else{
        cantNoAtendidos +=cantSolicitada;
    }
}

void Restaurante::modificarDatos(int dni,const char *aux,int cantSolicitada){
    int posCli=buscarCliente(dni);
    int posPla=buscarPlato(aux);
    int cantAtendidos = 0 , cantNoAtendidos = 0,cantPreparadas ;
    double descPlato=0.0,precio=0.0,pagado=0.0,desCliente=0.0,totalNeto = 0.0,
            bruto = 0.0, neto = 0.0;
    if(posPla>=0){
        cantPreparadas = platos[posPla].getPreparados();
        sacarDatos(posCli,posPla,cantAtendidos,cantNoAtendidos,precio,pagado,bruto,neto,cantSolicitada);
        if(cantAtendidos < cantPreparadas){
            platos[posPla].setAtendidos(cantAtendidos);
            platos[posPla].setTotalBruto(bruto);
            platos[posPla].setTotalNeto(neto);
            if(posCli>=0){
                clientes[posCli].setTotalPagado(pagado);
            } 
        }
        platos[posPla].setNoAtendidos(cantNoAtendidos);
        
    }
     
}

void Restaurante::operator >> (const char *archivo){
    ofstream arch=abrirArchEscribir(archivo);
    
    crearLinea(arch,'=',TAMLINEA);
    for(int i=0;i<cantPlatos;i++){
        arch<<right<<setw(3)<<i+1<<") ";
        arch<<platos[i];
    }
    arch<<endl<<endl;
    crearLinea(arch,'=',TAMLINEA);
    for(int i=0;i<cantClientes;i++){
        arch<<right<<setw(3)<<i+1<<") ";
        arch<<clientes[i];
    }
    
}
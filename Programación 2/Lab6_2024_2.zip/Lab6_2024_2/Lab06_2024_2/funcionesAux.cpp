
/* 
 * File:   funcionesAux.cpp
 * Author: AXEL
 * 
 * Created on 1 de junio de 2025, 23:23
 */

#include <iostream>
#include <fstream>
#include <cstring>
#include <iomanip>
using namespace std;
#include "funcionesAux.h"

char* leerCadena(ifstream &arch,char delimitador){
    char *aux,buff[200];
    arch.getline(buff,200,delimitador);
    if(strlen(buff)==0)return nullptr;
    aux=new char[strlen(buff)+1];
    strcpy(aux,buff);
    return aux;
}

ifstream abrirArchLectura(const char*name){
    ifstream archivo(name,ios::in);
    if(not archivo.is_open()){
        cout<<"ERROR EN LA APERTURA DEL ARCHIVO "<<name;
        exit(1);
    }
    return archivo;
}

ofstream abrirArchEscribir(const char*name){
    ofstream archivo(name,ios::out);
    if(not archivo.is_open()){
        cout<<"ERROR EN LA APERTURA DEL ARCHIVO "<<name;
        exit(1);
    }
    return archivo;
}

void crearLinea(ofstream &arch,char caracter, int tam){
    arch.fill(caracter);
    arch<<right<<setw(tam)<<' '<<endl;
    arch.fill(' ');
}

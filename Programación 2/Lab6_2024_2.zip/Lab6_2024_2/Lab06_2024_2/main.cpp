/* 
 * File:   main.cpp
 * Author: AXEL
 *
 * Created on 1 de junio de 2025, 15:00
 */

#include <iostream>
#include <iomanip>
using namespace std;
#include "Restaurante.h"

/*
 * 
 */
int main(int argc, char** argv) {
    class Restaurante restaurante;
    restaurante < "Clientes.csv";
    restaurante <= "PlatosOfrecidos.csv";
    restaurante <<= "Pedidos.csv";
    restaurante >> "ReporteDeVentasDelDia.txt";
    return 0;
}


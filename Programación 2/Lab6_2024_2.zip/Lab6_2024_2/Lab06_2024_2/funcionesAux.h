/* 
 * File:   funcionesAux.h
 * Author: AXEL
 *
 * Created on 1 de junio de 2025, 23:23
 */

#ifndef FUNCIONESAUX_H
#define FUNCIONESAUX_H

char* leerCadena(ifstream &arch,char delimitador);
ifstream abrirArchLectura(const char*name);
ofstream abrirArchEscribir(const char*name);
void crearLinea(ofstream &arch,char caracter, int tam);
#endif /* FUNCIONESAUX_H */

/* 
 * File:   Cliente.cpp
 * Author: AXEL
 * 
 * Created on 1 de junio de 2025, 15:15
 */
#include <iostream>
#include <cstring>
#include <iomanip>
using namespace std;
#include "Cliente.h"
#include "funcionesAux.h"
//constructores
Cliente::Cliente() {
    inicializa();
}
void Cliente::inicializa(){
    nombre=nullptr;
    descuento=0.0;
    distrito=nullptr;
    dni=0;
    totalPagado=0.0;    
    
}

Cliente::Cliente(const Cliente& orig) {
    inicializa();
    *this=orig;
}

void Cliente::operator =(const Cliente &orig){
    char aux[100];
    orig.getNombre(aux);
    setNombre(aux);
    dni=orig.dni;
    descuento=orig.descuento;
    orig.getDistrito(aux);
    setDistrito(aux);
    totalPagado=orig.totalPagado;   
    
}
//setters
void Cliente::setDni(int dni){
    this->dni=dni;
}

void Cliente::setNombre(const char*name){
    if(nombre!=nullptr)delete nombre;
    nombre=new char[strlen(name)+1];
    strcpy(nombre,name);
}

void Cliente::setDistrito(const char*distrit){
    if(distrito!=nullptr)delete distrito;
    distrito=new char[strlen(distrit)+1];
    strcpy(distrito,distrit);
}

void Cliente::setDescuento(double descuento){
    this->descuento=descuento;
}

void Cliente::setTotalPagado(double totalPagado){
    this->totalPagado=totalPagado;
}
//getters
int Cliente::getDni()const{
    return this->dni;
}

void Cliente::getNombre(char* name) const{
    if(nombre==nullptr)name[0]=0;
    else strcpy(name,nombre);
}

void Cliente::getDistrito(char* distrit)const{
    if(distrito==nullptr)distrit[0]=0;
    else strcpy(distrit,distrito);
}

double Cliente::getDescuento()const{
    return this->descuento;
}

double Cliente::getTotalPagado()const{
    return this->totalPagado;
}



//destructores
void Cliente::elimina(){
    if(nombre!=nullptr)delete nombre;
    if(distrito!=nullptr)delete distrito;
}

Cliente::~Cliente() {
    elimina();
}
//90367684,CORONEL CHUMPITAZ HELI,Villa Maria del Triunfo,S,13.04%
void operator >>(ifstream &arch,class Cliente &cliente){
    int dni;
    char *name,*distrito,posDesc,c;
    double desc=0;
    arch>>dni;
    if(arch.eof())return;
    arch.ignore();
    name=leerCadena(arch,',');
    distrito=leerCadena(arch,',');
    arch>>posDesc;
    if(posDesc=='S'){
        arch>>c>>desc>>c;
    }
    cliente.setDescuento(desc);
    cliente.setDistrito(distrito);
    cliente.setDni(dni);
    cliente.setNombre(name);
}

void operator <<(ofstream &arch,class Cliente &cliente){
    char aux[100];
    arch<<right<<setw(8)<<cliente.getDni()<<setw(4)<<' '<<left;
    cliente.getNombre(aux);
    arch<<setw(60)<<aux;
    cliente.getDistrito(aux);
    arch<<setw(60)<<aux<<right<<fixed<<setprecision(2)<<setw(5)<<
            cliente.getDescuento()<<'%'<<setw(8)<<
            cliente.getTotalPagado()<<endl;
            
}

